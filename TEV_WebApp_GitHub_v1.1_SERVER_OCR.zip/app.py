from flask import Flask,request,jsonify,send_from_directory
import re,io,os,fitz,pytesseract
from PIL import Image
app=Flask(__name__,static_folder=".",static_url_path="")
@app.get("/")
def home(): return send_from_directory(".","OPEN_TEV_WEBSITE.html")
def clean(s): return re.sub(r"\s+"," ",s or "").strip(" :;\n\t")
def field(t,a,ends):
 m=re.search(re.escape(a)+r"\s*:?\s*(.*?)(?=\s*(?:"+"|".join(re.escape(x) for x in ends)+r")\s*:?)",t,re.I|re.S)
 return clean(m.group(1)) if m else ""
def parse(t,fn):
 t=clean(t)
 def rx(p):
  m=re.search(p,t,re.I|re.S);return clean(m.group(1)) if m else ""
 no=rx(r"Control\s*No\.?\s*:\s*([0-9-]+)")
 if not no:
  m=re.search(r"(20\d{2}-\d{2}-\d{4,6})",fn);no=m.group(1) if m else ""
 block=field(t,"NAMES",["Official Station"]); names=[]
 for m in re.finditer(r"([A-Z][A-Z .,'-]{4,}?)\s+(?:AGRICULTURIST|ENGINEER|SCIENCE RESEARCH|PROJECT|ADMINISTRATIVE|SUPERVISING|CHIEF|DIRECTOR)\b",block,re.I):
  n=clean(m.group(1)).upper()
  if n and n not in names:names.append(n)
 return {"toNumber":no,"employees":names,
 "departureDate":rx(r"Departure\s*Date\s*:\s*(\d{1,2}/\d{1,2}/\d{4})"),
 "returnDate":rx(r"Return\s*Date\s*:\s*(\d{1,2}/\d{1,2}/\d{4})"),
 "destination":field(t,"Destination",["Specific purpose of the trip","Specific purpose"]),
 "purpose":field(t,"Specific purpose of the trip",["Objective(s)","Objectives","Objective"])}
@app.post("/api/to")
def read_to():
 f=request.files.get("file")
 if not f:return jsonify({"error":"No file uploaded"}),400
 data=f.read()
 try:
  if (f.filename or "").lower().endswith(".pdf"):
   doc=fitz.open(stream=data,filetype="pdf"); chunks=[]
   for p in doc:
    embedded=p.get_text("text") or ""
    if len(embedded.strip())>300 and "Departure Date" in embedded: chunks.append(embedded)
    else:
     pix=p.get_pixmap(matrix=fitz.Matrix(2.5,2.5),alpha=False)
     chunks.append(pytesseract.image_to_string(Image.open(io.BytesIO(pix.tobytes("png"))),lang="eng",config="--psm 6"))
   text="\n".join(chunks)
  else:text=pytesseract.image_to_string(Image.open(io.BytesIO(data)).convert("RGB"),lang="eng",config="--psm 6")
  r=parse(text,f.filename or "")
  if not any([r["departureDate"],r["destination"],r["purpose"],r["employees"]]):return jsonify({"error":"OCR completed but fields were not recognized."}),422
  return jsonify(r)
 except Exception as e:return jsonify({"error":str(e)}),500
if __name__=="__main__":app.run(host="0.0.0.0",port=int(os.environ.get("PORT","8000")))
